# <p align="center" style="color:#cb3349" > [NightRang](https://telegram.me/hlil3)

 <p align="center" style="color: #000040;" > سورس نايترانج الاقوى والاحدث لحمايه المجموعات في التيليقرام

***

# <p align="center" style="color: #000040;" > اوامر التنصيب السورس ↓
```
git clone https://github.com/NightRang/NightRang ;cd NightRang ;chmod +x NightRang ; ./NightRang
```


```
» فقط أضغط على الكود وقم بنسخه .
» ثم الصقه بالترمنال وانتر تتنظر يتنصب .
» بعدها يطـلب مـعلومـات بالترمـنال .
» تدخل مـعلومـاتك مـن توكن ومـعرفك .
» وسـوف يعمـل البوت .
```
# <a align="center" >[View in Telegram](https://telegram.me/hlil3)</a>
